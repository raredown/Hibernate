package es.albarregas.dao;

import es.albarregas.modelo.Profesor;
import java.util.List;


public interface IProfesorDAO {
    
//    public void add(Profesor profesor);
//    public List<Profesor> get(String entidad);
    public Profesor getOne(int pk);
//    public ArrayList<Alumno> getAlumnosEquipo();
//    public void update(Profesor profesor);
//    public void delete(Profesor profesor);
//    public void closeConnection();
    
}