import es.albarregas.dao.AbstractDAO;

import es.albarregas.modelo.Normal;
import es.albarregas.modelo.Persona;
import es.albarregas.modelo.Programador;
import es.albarregas.modelo.Tecnologo;
import es.albarregas.modelo.Tester;
import java.util.Date;

public class App {

    
    public static void main(String[] args) {
        
        Normal normal = new Normal("normal", new Date(), "Empleado");
        Tecnologo tecnologo = new Tecnologo("tecnologo", new Date(), 4);
        Programador programador1 = new Programador("primer programador", new Date(), 4, "java", 4);
        Programador programador2 = new Programador("segundo programador", new Date(), 5, "java", 2);
        Tester tester = new Tester("tester", new Date(), 3, "JUnit");

//        AbstractDAO.almacenaEntidad(normal);
//        AbstractDAO.almacenaEntidad(tecnologo);
//        AbstractDAO.almacenaEntidad(programador1);
//        AbstractDAO.almacenaEntidad(programador2);
//        AbstractDAO.almacenaEntidad(tester);
        
        AbstractDAO.getEntidad(programador1.getId(), Persona.class);

    }
    
    
    
    
}
