package es.albarregas.modelo;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
//@DiscriminatorValue(value = "TS")
@Table(name = "testers1")
public class Tester extends Tecnologo {
    
    @Column(name = "HerramientaTesteo", length = 40)
    private String herramientaTesteo;

    public Tester() {
    }

    public Tester(String nombre, Date fechaNacimiento, int yearEstudios, String herramientaTesteo) {
        super(nombre, fechaNacimiento, yearEstudios);
        this.herramientaTesteo = herramientaTesteo;
    }

    public String getHerramientaTesteo() {
        return herramientaTesteo;
    }

    public void setHerramientaTesteo(String herramientaTesteo) {
        this.herramientaTesteo = herramientaTesteo;
    }
    
}
