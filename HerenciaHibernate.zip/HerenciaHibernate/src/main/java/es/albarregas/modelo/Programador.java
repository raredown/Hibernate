package es.albarregas.modelo;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
//@DiscriminatorValue(value = "PG")
@Table(name = "programadores1")
public class Programador extends Tecnologo {
    
    @Column(name = "LenguajeFavorito", length = 20)
    private String lenguajeFavorito;
    
    @Column(name = "YearExperiencia")
    private int yearExperiencia;

    public Programador() {
    }

    public Programador(String nombre, Date fechaNacimiento, int yearEstudios, String lenguajeFavorito, int yearExperiencia) {
        super(nombre, fechaNacimiento, yearEstudios);
        this.lenguajeFavorito = lenguajeFavorito;
        this.yearExperiencia = yearExperiencia;
    }

    public String getLenguajeFavorito() {
        return lenguajeFavorito;
    }

    public void setLenguajeFavorito(String lenguajeFavorito) {
        this.lenguajeFavorito = lenguajeFavorito;
    }

    public int getYearExperiencia() {
        return yearExperiencia;
    }

    public void setYearExperiencia(int yearExperiencia) {
        this.yearExperiencia = yearExperiencia;
    }
    
}
