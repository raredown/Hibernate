package es.albarregas.modelo;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
//@DiscriminatorValue(value = "NM")
@Table(name = "normales1")
public class Normal extends Persona {
    
    @Column(name = "Ocupacion", length = 20)
    private String ocupacion;

    public Normal() {
    }

    public Normal(String nombre, Date fechaNacimiento, String ocupacion) {
        super(nombre, fechaNacimiento);
        this.ocupacion = ocupacion;
    }
    
    public String getOcupacion() {
        return ocupacion;
    }

    public void setOcupacion(String ocupacion) {
        this.ocupacion = ocupacion;
    }
    
}
