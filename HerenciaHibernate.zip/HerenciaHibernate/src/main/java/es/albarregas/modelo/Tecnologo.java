package es.albarregas.modelo;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
//@DiscriminatorValue(value = "TC")
@Table(name = "tecnologos1")
public class Tecnologo extends Persona {
    
    @Column(name = "YearEstudios")
    private int yearEstudios;

    public Tecnologo() {
    }

    public Tecnologo(String nombre, Date fechaNacimiento, int yearEstudios) {
        super(nombre, fechaNacimiento);
        this.yearEstudios = yearEstudios;
    }

    public int getYearEstudios() {
        return yearEstudios;
    }

    public void setYearEstudios(int yearEstudios) {
        this.yearEstudios = yearEstudios;
    }
    
}
